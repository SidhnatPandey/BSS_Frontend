import { Component, OnInit, ElementRef } from "@angular/core";
import * as d3 from "d3";
import * as topojson from "topojson-client";
import {
  Feature,
  FeatureCollection,
  Geometry,
  GeoJsonProperties,
} from "geojson";
import { Topology, GeometryCollection, Objects } from "topojson-specification";

interface FlightPath {
  source: [number, number];
  destination: [number, number];
  status: "active" | "delayed" | "completed";
}

// Define TopoJSON types
interface TopoGeometry {
  type: string;
  geometries: Array<{
    type: string;
    properties: any;
    coordinates: number[][][];
  }>;
}

interface TopologyObjects {
  [key: string]: TopoGeometry;
  countries: TopoGeometry;
}

/* interface Topology {
  type: "Topology";
  objects: TopologyObjects;
  arcs: number[][][];
  transform: {
    scale: [number, number];
    translate: [number, number];
  };
}
 */
interface WorldTopology
  extends Topology<{
    countries: GeometryCollection;
  }> {}

@Component({
  selector: "app-flight-path",
  standalone: true,
  imports: [],
  templateUrl: "./flight-path.component.html",
  styleUrl: "./flight-path.component.css",
})
export class FlightPathComponent implements OnInit {
  private svg: any;
  private g: any;
  private width = 960;
  private height = 500;
  private projection!: d3.GeoProjection;
  private path!: d3.GeoPath;

  private flightPaths: FlightPath[] = [
    {
      source: [-73.7781, 40.6413], // JFK Airport
      destination: [2.5559, 49.0083], // Paris CDG
      status: "active",
    },
    // Add more flight paths as needed
  ];

  constructor(private elementRef: ElementRef) {}

  ngOnInit() {
    this.initializeMap();
    this.drawFlightPaths();
    this.animateFlights();
  }

  private initializeMap() {
    this.svg = d3
      .select(this.elementRef.nativeElement.querySelector("svg"))
      .attr("viewBox", `0 0 ${this.width} ${this.height}`);

    this.projection = d3
      .geoMercator()
      .scale(140)
      .center([0, 20])
      .translate([this.width / 2, this.height / 2]);

    this.path = d3.geoPath().projection(this.projection);
    this.g = this.svg.append("g");

    // Load and draw world map with proper typing
    d3.json<WorldTopology>(
      "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json"
    )
      .then((topology) => {
        if (topology) {
          const geojson = topojson.feature(
            topology,
            topology.objects.countries
          );

          this.g
            .selectAll("path")
            .data(geojson.features)
            .enter()
            .append("path")
            .attr("class", "country")
            .attr("d", this.path);
        } else {
          console.error("Failed to load topology data");
        }
      })
      .catch((error) => {
        console.error("Error loading topology:", error);
      });
  }
  private drawFlightPaths() {
    this.flightPaths.forEach((flightPath) => {
      // Create curved path between points
      const route: Feature<Geometry> = {
        type: "Feature",
        geometry: {
          type: "LineString",
          coordinates: [flightPath.source, flightPath.destination],
        },
        properties: {},
      };

      // Draw the path
      this.g
        .append("path")
        .datum(route)
        .attr("class", "flight-path")
        .attr("d", this.path);

      // Add points for airports
      [flightPath.source, flightPath.destination].forEach((point) => {
        this.g
          .append("circle")
          .attr("class", "flight-point")
          .attr("r", 3)
          .attr("transform", `translate(${this.projection(point)})`);
      });
    });
  }

  private animateFlights() {
    this.flightPaths.forEach((flightPath) => {
      // Create airplane symbol
      const airplane = this.g
        .append("path")
        .attr("class", `airplane ${flightPath.status}`)
        .attr("d", "M -10,-3 L 10,0 L -10,3 Z"); // Simple triangle for airplane

      // Create path for animation
      const route: Feature<Geometry> = {
        type: "Feature",
        geometry: {
          type: "LineString",
          coordinates: [flightPath.source, flightPath.destination],
        },
        properties: {},
      };

      // Animation
      const repeat = () => {
        const pathNode = this.g
          .append("path")
          .datum(route)
          .attr("d", this.path)
          .style("display", "none");

        const length = pathNode.node().getTotalLength();

        airplane
          .transition()
          .duration(length * 50) // Adjust speed as needed
          .attrTween("transform", () => {
            return (t: any) => {
              const p = pathNode.node().getPointAtLength(t * length);
              const angle = this.calculateAngle(pathNode.node(), t * length);
              return `translate(${p.x},${p.y}) rotate(${angle})`;
            };
          })
          .on("end", repeat); // Repeat animation
      };

      repeat();
    });
  }

  private calculateAngle(path: any, length: number): number {
    const precision = 10;
    const p1 = path.getPointAtLength(length - precision);
    const p2 = path.getPointAtLength(length + precision);
    return (Math.atan2(p2.y - p1.y, p2.x - p1.x) * 180) / Math.PI;
  }
}
